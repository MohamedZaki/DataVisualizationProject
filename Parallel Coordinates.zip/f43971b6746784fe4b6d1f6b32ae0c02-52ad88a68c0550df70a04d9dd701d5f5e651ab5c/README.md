Built with [blockbuilder.org](http://blockbuilder.org)

forked from <a href='http://bl.ocks.org/MohamedZaki/'>MohamedZaki</a>'s block: <a href='http://bl.ocks.org/MohamedZaki/adb03e4c9a61555581e416a62d59954f'>Parallel Coordinates</a>